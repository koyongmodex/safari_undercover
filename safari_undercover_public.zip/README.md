# Safari Undercover
A simple fullscreen video app.